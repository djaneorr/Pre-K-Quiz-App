package com.example.pre_kquizapp

object Constants {

    fun getQuestions(): ArrayList<Question>{
        val questionsList = ArrayList<Question>()

        //Each question follows the layout in Question.kt, and this is what we will use to
        // have the questions on the screen.
        val que1 = Question(1, "What shape is this?",
            R.drawable.triangle,
            "Circle",
            "Square",
            "Triangle",
            "Diamond",
            3
        )
        val que2 = Question(1, "What shape is this?",
            R.drawable.circle,
            "Circle",
            "Square",
            "Triangle",
            "Diamond",
            1
        )
        val que3 = Question(1, "What shape is this?",
            R.drawable.diamond,
            "Circle",
            "Square",
            "Triangle",
            "Diamond",
            4
        )
        val que4 = Question(1, "What shape is this?",
            R.drawable.square,
            "Circle",
            "Square",
            "Triangle",
            "Diamond",
            2
        )
        questionsList.add(que1)
        questionsList.add(que2)
        questionsList.add(que3)
        questionsList.add(que4)
        return questionsList
    }

}